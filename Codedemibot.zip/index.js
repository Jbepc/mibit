    const aoi = require('aoi.js');
const token = process.env['token']
const bot = new aoi.Bot({
  token:token,
  prefix: ['f/'],
  intents: "all"
});

bot.onMessage();

bot.command({
  name: "say",
  code: `
$description[$message]
$color[RANDOM]
`
})

bot.command({
name: "nuke",
code: `
$clear[100]
$clear[100]
$clear[100]
$clear[100]
$description[canal nukeado por: <@$authorID>]
$color[RANDOM]`})


const monitor = new Monitor({
  website: 'LINK',
  title: 'NAME',
  interval: 2 
});

monitor.on('up', (res) => console.log(`${res.website} esta encendido.`));
monitor.down('down', (res) => console.log(`${res.website} se ha caido - ${res.statusMessage}`));
monitor.on('stop', (website) => console.log(`${website} se ha parado.`) );
monitor.on('error', (error) => console.log(error));